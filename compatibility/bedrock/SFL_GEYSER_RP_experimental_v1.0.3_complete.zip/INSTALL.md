# Optional Bedrock resource packs — complete-install candidate

Geyser is required. Install both the supplied `packs/` and `custom_mappings/`
contents in the active Geyser data directory. These are resource and mapping
files; this ZIP does not include a Geyser JAR or replace the Java server plugins.

This complete candidate includes the 20 original Slimefun item-mapping JSONs,
the original 1,453-skull mapping, the additional 90-skull mapping, the Albion
ValhallaMMO item mapping, and both updated main packs. The two separate skull
JSONs contain 1,543 unique hashes. No mappings were merged or rewritten.

## Install or update

1. Stop Geyser normally. For Geyser-Spigot, stop the server normally and back up
   its Geyser data directory before changing files.
2. Use the actual Geyser data directory: normally `plugins/Geyser-Spigot/` for
   the plugin, or the standalone working directory. Do not create another
   nested `Geyser-Spigot/` directory.
3. If updating, move `SlimefunBedrockRP.mcpack` and
   `Albion_ValhallaMMO_Bedrock_1.0.0.mcpack` outside the active `packs/` directory.
   The updated main packs retain their UUIDs; only one version of each main
   pack should be active. Preserve unrelated packs and mappings.
4. Copy this ZIP's `packs/` and `custom_mappings/` contents into the matching
   Geyser directories. The base mappings needed for a fresh installation are
   already included; no earlier ZIP is required.
5. Optional: copy `optional/Albion_ValhallaMMO_Stat_Icons_1.0.0.mcpack` into the
   active `packs/` directory if you want the ValhallaMMO stat/effect text icons.
   The `optional/` location is not active by default. Keep at most one installed
   copy; this optional pack is unchanged from the earlier bundle.
6. Start Geyser fully, reconnect Bedrock players, and accept the pack update.
   Geyser fetches uncached public skull textures and generates its skull pack.
   A complete restart is required for new item/skull registrations.

## Scope and retained notes

All 27 supplied component files are preserved byte-for-byte. Only this outer
complete-install ZIP and `INSTALL.md` are newly assembled. The 107 existing
Slimefun texture-size deprecation warnings remain; their mappings need a
separate attachable migration. Missing artwork described by the upstream
README is not replaced with a different item's texture.

`README.txt` is retained unchanged as upstream history. Its prerequisite for
existing base mappings is already satisfied by this complete bundle. The
validation reports it mentions were not present in the supplied overlay;
its runtime counts and other server-log claims are not independently supplied
evidence for this candidate. Separate loader checks do not establish Bedrock
client rendering or live gameplay compatibility.

This is a local reviewable candidate. It has not been published as a release.
