ALBION BEDROCK RESOURCE REPAIRS — 1.0.1
Prepared 21 October 2026 (America/New_York).

WHAT THIS FIXES
1. ValhallaMMO: restores all 576 custom model files to models/entity/av/.
   The previous pack placed them in models/av/entity/, which is outside the
   recognized model roots. This explains the client 'geometry not found?'
   messages. Geometry contents, textures, animations and item IDs are preserved.
   The main pack version changes from 1.0.0 to 1.0.1; its UUIDs are preserved.

2. Slimefun default player heads: adds the 90 core HeadTexture skin hashes
   missing from your existing 1,453 skull registrations. These include Cargo
   Manager, Connector Node, Input Node, Output/Advanced Output Node, and Cargo
   Motor. The existing skull mapping stays installed. Geyser generates the
   textures and geometry for these heads when it starts.
   The defaults were checked against Slimefun Legacy v4.1.75, commit
   7f702e3565a381aeeefd99555f2c8fe818858e9c. No item IDs or CMD values change.
   Customized profiles and addon heads not listed in that source are outside
   this addition. A matching ordinary custom-item CMD mapping still takes
   priority over the skull fallback.

3. Slimefun armor: repairs an extra closing brace in entity.material and four
   gilded-iron armor texture references, using the correct PNGs already present.
   Slimefun pack version is now 1.0.1, with the same UUIDs and archive layout.

INSTALL — USE THE REAL GEYSER DATA DIRECTORY
For this Paper server, that is plugins/Geyser-Spigot/.
Do not extract another Geyser-Spigot folder inside it.

1. Stop the server and keep backups of the old pack files outside packs/.
2. Move these old files out of the active packs/ directory:
   Albion_ValhallaMMO_Bedrock_1.0.0.mcpack
   SlimefunBedrockRP.mcpack
   Do not leave both versions installed: each update retains its pack UUID.
3. Copy the CONTENTS of this bundle's packs/ and custom_mappings/ folders into
   the matching existing folders under plugins/Geyser-Spigot/.
   Merge the folders; do not replace their complete contents.
4. Keep all existing SF-*.json, SlimefunItems.json and
   migrated-custom-skulls.json files. The new skull JSON adds missing profiles.
   The included albion_valhallammo_mappings.json is byte-identical to yours.
5. Keep the optional Albion_ValhallaMMO_Stat_Icons_1.0.0.mcpack already installed.
   It is unchanged. An optional copy is included for completeness.
6. Start the server fully, then reconnect Bedrock and accept the pack update.
   A full restart is required for new skull/item registrations.

Installed files from this overlay:
plugins/Geyser-Spigot/packs/Albion_ValhallaMMO_Bedrock_1.0.1.mcpack
plugins/Geyser-Spigot/packs/SlimefunBedrockRP_1.0.1.mcpack
plugins/Geyser-Spigot/custom_mappings/albion_valhallammo_mappings.json
plugins/Geyser-Spigot/custom_mappings/albion_slimefun_legacy_skulls.json

Geyser manages and rebuilds its generated skull resource pack. No blanket cache
deletion is required. The first startup with the additional hashes fetches any
uncached skins. With the supplied mapping set, expect 1,543 registered custom
skulls if all skins download successfully (previously 1,453).

VERIFIED
- Actual old Valhalla archive fails the strengthened model-directory gate.
- Corrected archive passes static validation with all 576 geometry definitions
  discoverable, all 507 item definitions and 505 source item/CMD pairs present.
- Exact comparison: model bytes, image bytes, animations and mapping JSON are
  unchanged. Only geometry paths, manifest version and credits version change.
- All 73 animated items / 431 frame geometries pass structural checks.
- Slimefun repair changes six files only; every JSON/material file parses and
  all four corrected armor paths resolve to existing assets.
- All 90 added hashes are exact source defaults, unique and absent from your
  existing set. Combined registration has 1,543 unique hashes.
- An isolated official Geyser 2.12.0-b1268 startup loaded the repaired packs and
  uploaded active mappings plus the new skull file. It registered 1,543 skulls,
  1,550 total custom blocks, and 1,070 ordinary custom items. Geyser fetched all
  90 added textures and built a pack containing every added hash, with no
  missing skull PNG references. Shutdown was clean.

The validation reports are included. No Bedrock client connected to the local
test; this is not a claim that the repaired pack has been visually confirmed.

FRESH BEDROCK CHECK
Check a Valhalla weapon in hand, an animated item, and worn armor. The previous
albion_valhalla geometry-not-found messages should disappear.
Open the Slimefun guide and inspect Cargo Manager, Connector, Input and Output
Nodes, then hold and place a node. These use different item/block paths, so
check both. If only placed heads are wrong, verify custom skull display is
enabled in /geyser settings and inspect them at close range.

If an affected head still appears vanilla, hold it and obtain its actual Java
item data/profile, and state whether the problem is in inventory/hand, when
placed, or both. That distinguishes customized profiles from unmapped CMD.

KNOWN REMAINING ISSUES
- The 107 Slimefun texture_size deprecation warnings remain. Their mappings
  need a separate attachable migration; the current Geyser still registers them.
- automated_crafting_chamber (player_head CMD 2200516) references an icon PNG
  absent from both your supplied Slimefun pack and its upstream tree. Its
  artwork was not substituted with a different item's icon.
- The Slimefun GUI aliases wiki and ui_background_2 also have no corresponding
  atlas entries or artwork in the supplied pack. These remain unsupported.
- The latest server log still has 109 interaction-entity metadata type warnings.
  Entity metadata field 10 expects a Boolean. Texture changes cannot correct
  malformed or incorrectly translated entity packets; the sender is unidentified.
- Duplicate/skipped recipe messages originate in the Java-to-Bedrock recipe
  stream. None of these visual packs contains recipes, and this repair does not
  alter server recipes or claim to resolve those messages.
- Other errors in the supplied server log (ItemsAdder, InfinityExpansion2,
  Rebar and Multiverse) are outside this pack repair.

SOURCES
https://learn.microsoft.com/en-us/minecraft/creator/documents/addcustomitems?view=minecraft-bedrock-stable
https://geysermc.org/wiki/geyser/custom-skulls/
https://github.com/wickidcow/Slimefun-Legacy/blob/7f702e3565a381aeeefd99555f2c8fe818858e9c/src/main/java/io/github/thebusybiscuit/slimefun4/utils/HeadTexture.java
https://github.com/SofiaRedmond/Slimefun-Geyser-RP/tree/588da966cadac69abc643857c4db2f214a12618c

Original Valhalla artwork: Athlaeos / ValhallaMMO. Slimefun pack artwork remains
credited to its supplied/upstream authors. This private repair preserves their
artwork and existing notices; it does not relicense them.
